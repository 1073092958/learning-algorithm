create view productcustomers as
select `examples`.`customers`.`cust_name`    AS `cust_name`,
       `examples`.`customers`.`cust_contact` AS `cust_contact`,
       `examples`.`orderitems`.`prod_id`     AS `prod_id`
from `examples`.`customers`
         join `examples`.`orders`
         join `examples`.`orderitems`
where ((`examples`.`customers`.`cust_id` = `examples`.`orders`.`cust_id`) and
       (`examples`.`orderitems`.`order_num` = `examples`.`orders`.`order_num`));

